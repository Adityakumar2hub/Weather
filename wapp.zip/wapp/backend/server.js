const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const { connectDatabase } = require("./config/db");
const weatherRoutes = require("./routes/weatherRoutes");

const app = express();
const port = Number(process.env.PORT || 5000);
const frontendPath = path.join(__dirname, "..", "frontend");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(frontendPath));
app.use("/api", weatherRoutes);

app.get("/", (_req, res) => {
  res.sendFile(path.join(frontendPath, "index.html"));
});

app.use((req, res) => {
  if (req.path.startsWith("/api")) {
    return res.status(404).json({ success: false, message: "API route not found." });
  }

  return res.sendFile(path.join(frontendPath, "index.html"));
});

async function startServer() {
  try {
    await connectDatabase();
    app.listen(port, () => {
      console.log(`Weather app server running on http://localhost:${port} && Database connected`);
    });
  } catch (error) {
    console.error("Failed to connect to MongoDB:", error.message);
    process.exit(1);
  }
}

startServer();
