const express = require("express");
const { getDatabaseStatus } = require("../config/db");
const {
  getWeather,
  registerUser,
  getUser,
  listFavorites,
  saveFavorite,
  removeFavorite,
  listSearches,
} = require("../controllers/weatherController");

const router = express.Router();

router.get("/health", (_req, res) => {
  res.json({
    success: true,
    message: "Weather API is running.",
    database: getDatabaseStatus(),
  });
});

router.get("/weather/:city", getWeather);
router.post("/users/register", registerUser);
router.get("/users/:userId", getUser);
router.get("/users/:userId/favorites", listFavorites);
router.post("/users/:userId/favorites", saveFavorite);
router.delete("/users/:userId/favorites/:city", removeFavorite);
router.get("/searches", listSearches);

module.exports = router;
