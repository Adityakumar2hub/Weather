const axios = require("axios");
const { mongoose } = require("../config/db");
const { createUser, getUserByEmail, getUserById } = require("../models/User");
const {
  getFavoritesByUserId,
  addFavorite,
  deleteFavorite,
  isFavorite,
} = require("../models/Favorite");
const {
  logSearch,
  getSearchHistory,
  getWeatherCache,
  upsertWeatherCache,
} = require("../models/Weather");

const CACHE_TTL_MS = 30 * 60 * 1000;

function normalizeCity(city) {
  return String(city || "").trim().toLowerCase();
}

function formatCity(city) {
  return String(city || "")
    .trim()
    .replace(/\s+/g, " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function weatherMeta(code, isDay = true) {
  const iconSuffix = isDay ? "d" : "n";

  if (code === 0) return { main: "Clear", description: "clear sky", icon: `01${iconSuffix}` };
  if ([1, 2].includes(code)) return { main: "Clouds", description: "partly cloudy", icon: `02${iconSuffix}` };
  if (code === 3) return { main: "Clouds", description: "overcast clouds", icon: `04${iconSuffix}` };
  if ([45, 48].includes(code)) return { main: "Fog", description: "foggy", icon: `50${iconSuffix}` };
  if ([51, 53, 55].includes(code)) return { main: "Drizzle", description: "light drizzle", icon: `09${iconSuffix}` };
  if ([56, 57].includes(code)) return { main: "Drizzle", description: "freezing drizzle", icon: `09${iconSuffix}` };
  if ([61, 63, 65].includes(code)) return { main: "Rain", description: "rainy", icon: `10${iconSuffix}` };
  if ([66, 67].includes(code)) return { main: "Rain", description: "freezing rain", icon: `10${iconSuffix}` };
  if ([71, 73, 75, 77].includes(code)) return { main: "Snow", description: "snowy", icon: `13${iconSuffix}` };
  if ([80, 81, 82].includes(code)) return { main: "Rain", description: "showers", icon: `09${iconSuffix}` };
  if ([85, 86].includes(code)) return { main: "Snow", description: "snow showers", icon: `13${iconSuffix}` };
  if ([95, 96, 99].includes(code)) return { main: "Thunderstorm", description: "thunderstorm", icon: `11${iconSuffix}` };
  return { main: "Clouds", description: "cloudy", icon: `03${iconSuffix}` };
}

function getWindDirection(deg) {
  const directions = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  return directions[Math.round(Number(deg || 0) / 45) % 8];
}

function isFresh(updatedAt) {
  return Date.now() - new Date(updatedAt).getTime() < CACHE_TTL_MS;
}

function buildFallbackWeather(cityInput) {
  const city = formatCity(cityInput);
  const forecast = Array.from({ length: 5 }, (_, index) => {
    const date = new Date();
    date.setDate(date.getDate() + index);
    const weatherCode = [0, 1, 2, 3, 61][index % 5];
    const meta = weatherMeta(weatherCode, true);
    const tempMin = 20 + index;
    const tempMax = tempMin + 6;

    return {
      date: date.toISOString().split("T")[0],
      temp: Math.round((tempMin + tempMax) / 2),
      tempMin,
      tempMax,
      humidity: 55 + index * 4,
      description: meta.description,
      icon: meta.icon,
      main: meta.main,
      windSpeed: 8 + index,
    };
  });

  return {
    location: {
      name: city,
      country: "NA",
      latitude: 0,
      longitude: 0,
    },
    current: {
      city,
      country: "NA",
      temp: 28,
      feelsLike: 31,
      tempMin: 24,
      tempMax: 32,
      humidity: 60,
      pressure: 1012,
      visibility: 10000,
      description: "weather service unavailable - showing fallback data",
      icon: "03d",
      main: "Clouds",
      windSpeed: 10,
      windDeg: 180,
      clouds: 40,
      weatherCode: 3,
    },
    forecast,
  };
}

async function geocodeCity(city) {
  const response = await axios.get("https://geocoding-api.open-meteo.com/v1/search", {
    params: {
      name: city,
      count: 1,
      language: "en",
      format: "json",
    },
    timeout: 15000,
  });

  const result = response.data?.results?.[0];
  if (!result) return null;

  return {
    name: result.name,
    country: result.country_code || result.country || "",
    latitude: result.latitude,
    longitude: result.longitude,
  };
}

async function fetchWeatherFromApi(location) {
  const response = await axios.get("https://api.open-meteo.com/v1/forecast", {
    params: {
      latitude: location.latitude,
      longitude: location.longitude,
      current: [
        "temperature_2m",
        "relative_humidity_2m",
        "surface_pressure",
        "wind_speed_10m",
        "wind_direction_10m",
        "cloud_cover",
        "apparent_temperature",
        "weather_code",
        "is_day",
      ].join(","),
      daily: [
        "temperature_2m_max",
        "temperature_2m_min",
        "weather_code",
        "wind_speed_10m_max",
        "relative_humidity_2m_mean",
      ].join(","),
      timezone: "auto",
    },
    timeout: 15000,
  });

  const current = response.data.current;
  const daily = response.data.daily;
  const currentMeta = weatherMeta(current.weather_code, current.is_day === 1);

  return {
    location,
    current: {
      city: formatCity(location.name),
      country: location.country,
      temp: Math.round(current.temperature_2m),
      feelsLike: Math.round(current.apparent_temperature),
      tempMin: Math.round(daily.temperature_2m_min[0]),
      tempMax: Math.round(daily.temperature_2m_max[0]),
      humidity: Math.round(current.relative_humidity_2m),
      pressure: Math.round(current.surface_pressure),
      visibility: 10000,
      description: currentMeta.description,
      icon: currentMeta.icon,
      main: currentMeta.main,
      windSpeed: Number(current.wind_speed_10m),
      windDeg: Number(current.wind_direction_10m),
      clouds: Number(current.cloud_cover),
      weatherCode: Number(current.weather_code),
    },
    forecast: daily.time.slice(0, 5).map((date, index) => {
      const dayMeta = weatherMeta(daily.weather_code[index], true);
      return {
        date,
        temp: Math.round((daily.temperature_2m_max[index] + daily.temperature_2m_min[index]) / 2),
        tempMin: Math.round(daily.temperature_2m_min[index]),
        tempMax: Math.round(daily.temperature_2m_max[index]),
        humidity: Math.round(daily.relative_humidity_2m_mean[index] || current.relative_humidity_2m),
        description: dayMeta.description,
        icon: dayMeta.icon,
        main: dayMeta.main,
        windSpeed: Math.round(daily.wind_speed_10m_max[index] || current.wind_speed_10m),
      };
    }),
  };
}

function composeWeatherResponse(cacheRow) {
  const cachedForecast = Array.isArray(cacheRow.forecast)
    ? cacheRow.forecast
    : typeof cacheRow.forecast === "string"
      ? JSON.parse(cacheRow.forecast || "[]")
      : [];

  return {
    location: {
      name: cacheRow.city,
      country: cacheRow.country,
      latitude: cacheRow.latitude,
      longitude: cacheRow.longitude,
    },
    current: {
      city: formatCity(cacheRow.city),
      country: cacheRow.country,
      temp: Number(cacheRow.temperature),
      feelsLike: Number(cacheRow.feelsLike),
      tempMin: Number(cacheRow.temperature),
      tempMax: Number(cacheRow.temperature),
      humidity: Number(cacheRow.humidity),
      pressure: Number(cacheRow.pressure),
      visibility: 10000,
      description: cacheRow.description,
      icon: cacheRow.icon,
      main: weatherMeta(cacheRow.weatherCode, true).main,
      windSpeed: Number(cacheRow.windSpeed),
      windDeg: Number(cacheRow.windDirection),
      clouds: 0,
      weatherCode: Number(cacheRow.weatherCode),
    },
    forecast: cachedForecast,
  };
}

async function getWeather(req, res) {
  try {
    const cityInput = String(req.params.city || "").trim();
    const userId = req.query.userId ? String(req.query.userId).trim() : null;
    const validUserId = userId && mongoose.Types.ObjectId.isValid(userId) ? userId : null;

    if (!cityInput) {
      return res.status(400).json({ success: false, message: "City is required." });
    }

    await logSearch(cityInput, validUserId);

    const normalizedCity = normalizeCity(cityInput);
    const cachedWeather = await getWeatherCache(normalizedCity);

    if (cachedWeather && isFresh(cachedWeather.updatedAt)) {
      const response = composeWeatherResponse(cachedWeather);
      const favoriteState = validUserId ? await isFavorite(validUserId, normalizedCity) : false;
      return res.json({
        success: true,
        source: "cache",
        data: response,
        isFavorite: favoriteState,
      });
    }

    let weatherData;

    try {
      const location = await geocodeCity(cityInput);
      if (!location) {
        return res.status(404).json({
          success: false,
          message: `Could not find weather data for "${cityInput}".`,
        });
      }

      weatherData = await fetchWeatherFromApi(location);
    } catch (apiError) {
      console.error("External weather API unavailable:", apiError.message);
      weatherData = buildFallbackWeather(cityInput);
    }

    await upsertWeatherCache(normalizedCity, weatherData);

    const favoriteState = validUserId ? await isFavorite(validUserId, normalizedCity) : false;
    return res.json({
      success: true,
      source: "api",
      data: weatherData,
      isFavorite: favoriteState,
    });
  } catch (error) {
    console.error("Weather lookup failed:", error.message);
    return res.status(500).json({
      success: false,
      message: "Weather lookup failed. Please try again.",
    });
  }
}

async function registerUser(req, res) {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();

    if (!name || !email) {
      return res.status(400).json({
        success: false,
        message: "Name and email are required.",
      });
    }

    const existingUser = await getUserByEmail(email);
    if (existingUser) {
      return res.json({ success: true, user: existingUser, message: "User already exists." });
    }

    const user = await createUser(name, email);
    return res.status(201).json({ success: true, user });
  } catch (error) {
    console.error("User registration failed:", error.message);
    return res.status(500).json({
      success: false,
      message: "Unable to register user.",
    });
  }
}

async function getUser(req, res) {
  try {
    const user = await getUserById(String(req.params.userId).trim());
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found." });
    }
    return res.json({ success: true, user });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Unable to load user." });
  }
}

async function listFavorites(req, res) {
  try {
    const userId = String(req.params.userId).trim();
    const user = await getUserById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found." });
    }
    const favorites = await getFavoritesByUserId(userId);
    return res.json({ success: true, favorites });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Unable to load favorites." });
  }
}

async function saveFavorite(req, res) {
  try {
    const userId = String(req.params.userId).trim();
    const city = normalizeCity(req.body.city || req.params.city);
    const user = await getUserById(userId);

    if (!city) {
      return res.status(400).json({ success: false, message: "City is required." });
    }

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found." });
    }

    await addFavorite(userId, city);
    const favorites = await getFavoritesByUserId(userId);
    return res.json({ success: true, favorites });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Unable to save favorite." });
  }
}

async function removeFavorite(req, res) {
  try {
    const userId = String(req.params.userId).trim();
    const city = normalizeCity(req.params.city);
    const user = await getUserById(userId);

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found." });
    }

    const favorites = await deleteFavorite(userId, city);
    return res.json({ success: true, favorites });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Unable to remove favorite." });
  }
}

async function listSearches(req, res) {
  try {
    const userId = req.query.userId ? String(req.query.userId).trim() : null;
    const limit = req.query.limit ? Number(req.query.limit) : 20;
    const searches = await getSearchHistory(userId && mongoose.Types.ObjectId.isValid(userId) ? userId : null, limit);
    return res.json({ success: true, searches });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Unable to load search history." });
  }
}

module.exports = {
  getWeather,
  registerUser,
  getUser,
  listFavorites,
  saveFavorite,
  removeFavorite,
  listSearches,
};
