const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
require("dotenv").config();

const mongoUri = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/weather_app";
const dataDir = path.join(__dirname, "..", "data");
const dataFile = path.join(dataDir, "appdb.json");
const dbState = {
  fallback: false,
  lastError: null,
};

mongoose.set("strictQuery", true);

async function connectDatabase() {
  if (mongoose.connection.readyState === 1) {
    dbState.fallback = false;
    dbState.lastError = null;
    return mongoose.connection;
  }

  try {
    await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 10000,
    });
    dbState.fallback = false;
    dbState.lastError = null;
    return mongoose.connection;
  } catch (error) {
    dbState.fallback = true;
    dbState.lastError = error.message;
    ensureFallbackStore();
    return null;
  }
}

function getDatabaseStatus() {
  const stateMap = {
    0: "disconnected",
    1: "connected",
    2: "connecting",
    3: "disconnecting",
  };

  if (dbState.fallback) {
    return {
      connected: true,
      state: "fallback-file",
      name: "local-json-store",
      host: dataFile,
      lastError: dbState.lastError,
    };
  }

  return {
    connected: mongoose.connection.readyState === 1,
    state: stateMap[mongoose.connection.readyState] || "unknown",
    name: mongoose.connection.name || null,
    host: mongoose.connection.host || null,
    lastError: dbState.lastError,
  };
}

function ensureFallbackStore() {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(
      dataFile,
      JSON.stringify({ users: [], favorites: [], searches: [], weatherCache: [] }, null, 2),
      "utf8"
    );
  }
}

function readFallbackStore() {
  ensureFallbackStore();
  return JSON.parse(fs.readFileSync(dataFile, "utf8"));
}

function writeFallbackStore(nextStore) {
  ensureFallbackStore();
  fs.writeFileSync(dataFile, JSON.stringify(nextStore, null, 2), "utf8");
}

function isFallbackMode() {
  return dbState.fallback;
}

module.exports = {
  connectDatabase,
  getDatabaseStatus,
  readFallbackStore,
  writeFallbackStore,
  isFallbackMode,
  mongoose,
  mongoUri,
};
