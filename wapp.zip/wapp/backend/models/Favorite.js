const crypto = require("crypto");
const { mongoose, isFallbackMode, readFallbackStore, writeFallbackStore } = require("../config/db");

const favoriteSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    city: {
      type: String,
      required: true,
      trim: true,
    },
    cityLower: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      index: true,
    },
  },
  { timestamps: true }
);

favoriteSchema.index({ userId: 1, cityLower: 1 }, { unique: true });

const Favorite = mongoose.models.Favorite || mongoose.model("Favorite", favoriteSchema);

async function getFavoritesByUserId(userId) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    return store.favorites
      .filter((favorite) => favorite.userId === userId)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  if (!mongoose.Types.ObjectId.isValid(userId)) {
    return [];
  }

  const favorites = await Favorite.find({ userId }).sort({ createdAt: -1 }).lean();
  return favorites.map((favorite) => ({
    id: favorite._id.toString(),
    city: favorite.city,
    createdAt: favorite.createdAt,
  }));
}

async function addFavorite(userId, city) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    const cityText = String(city).trim();
    const cityLower = cityText.toLowerCase();
    const existingFavorite = store.favorites.find(
      (favorite) => favorite.userId === userId && favorite.cityLower === cityLower
    );

    if (!existingFavorite) {
      store.favorites.push({
        id: crypto.randomUUID(),
        userId,
        city: cityText,
        cityLower,
        createdAt: new Date().toISOString(),
      });
      writeFallbackStore(store);
    }

    return getFavoritesByUserId(userId);
  }

  if (!mongoose.Types.ObjectId.isValid(userId)) {
    return [];
  }

  const cityText = String(city).trim();
  const cityLower = cityText.toLowerCase();

  await Favorite.findOneAndUpdate(
    { userId, cityLower },
    { $set: { city: cityText, cityLower } },
    { upsert: true, new: true }
  );

  return getFavoritesByUserId(userId);
}

async function deleteFavorite(userId, city) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    const cityLower = String(city).trim().toLowerCase();
    store.favorites = store.favorites.filter(
      (favorite) => !(favorite.userId === userId && favorite.cityLower === cityLower)
    );
    writeFallbackStore(store);
    return getFavoritesByUserId(userId);
  }

  if (!mongoose.Types.ObjectId.isValid(userId)) {
    return [];
  }

  await Favorite.deleteOne({ userId, cityLower: String(city).trim().toLowerCase() });
  return getFavoritesByUserId(userId);
}

async function isFavorite(userId, city) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    return store.favorites.some(
      (favorite) =>
        favorite.userId === userId &&
        favorite.cityLower === String(city).trim().toLowerCase()
    );
  }

  if (!mongoose.Types.ObjectId.isValid(userId)) {
    return false;
  }

  const favorite = await Favorite.findOne({
    userId,
    cityLower: String(city).trim().toLowerCase(),
  }).lean();
  return Boolean(favorite);
}

module.exports = {
  Favorite,
  getFavoritesByUserId,
  addFavorite,
  deleteFavorite,
  isFavorite,
};
