const crypto = require("crypto");
const { mongoose, isFallbackMode, readFallbackStore, writeFallbackStore } = require("../config/db");

const searchSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
      index: true,
    },
    city: {
      type: String,
      required: true,
      trim: true,
    },
    cityLower: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      index: true,
    },
  },
  { timestamps: { createdAt: "searchedAt", updatedAt: false } }
);

const cacheSchema = new mongoose.Schema(
  {
    city: {
      type: String,
      required: true,
      trim: true,
    },
    cityLower: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      unique: true,
      index: true,
    },
    latitude: Number,
    longitude: Number,
    country: String,
    temperature: Number,
    feelsLike: Number,
    humidity: Number,
    pressure: Number,
    windSpeed: Number,
    windDirection: Number,
    description: String,
    weatherCode: Number,
    icon: String,
    forecast: {
      type: Array,
      default: [],
    },
  },
  { timestamps: true }
);

const WeatherSearch = mongoose.models.WeatherSearch || mongoose.model("WeatherSearch", searchSchema);
const WeatherCache = mongoose.models.WeatherCache || mongoose.model("WeatherCache", cacheSchema);

async function logSearch(city, userId = null) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    store.searches.push({
      id: crypto.randomUUID(),
      userId: userId || null,
      city: String(city).trim(),
      cityLower: String(city).trim().toLowerCase(),
      searchedAt: new Date().toISOString(),
    });
    writeFallbackStore(store);
    return;
  }

  await WeatherSearch.create({
    userId: userId && mongoose.Types.ObjectId.isValid(userId) ? userId : null,
    city: String(city).trim(),
    cityLower: String(city).trim().toLowerCase(),
  });
}

async function getSearchHistory(userId = null, limit = 20) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    const searches = store.searches
      .filter((search) => (userId ? search.userId === userId : true))
      .sort((a, b) => new Date(b.searchedAt) - new Date(a.searchedAt))
      .slice(0, Number(limit));

    return searches.map((search) => ({
      id: search.id,
      city: search.city,
      searched_at: search.searchedAt,
      user_name: null,
    }));
  }

  const filter = userId && mongoose.Types.ObjectId.isValid(userId) ? { userId } : {};
  const searches = await WeatherSearch.find(filter).sort({ searchedAt: -1 }).limit(Number(limit)).lean();

  return searches.map((search) => ({
    id: search._id.toString(),
    city: search.city,
    searched_at: search.searchedAt,
    user_name: search.userName || null,
  }));
}

async function getWeatherCache(city) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    return (
      store.weatherCache.find(
        (item) => item.cityLower === String(city).trim().toLowerCase()
      ) || null
    );
  }

  return WeatherCache.findOne({ cityLower: String(city).trim().toLowerCase() }).lean();
}

async function upsertWeatherCache(city, payload) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    const cityLower = String(city).trim().toLowerCase();
    const cacheItem = {
      id: crypto.randomUUID(),
      city: String(payload.location.name || city).trim(),
      cityLower,
      latitude: payload.location.latitude,
      longitude: payload.location.longitude,
      country: payload.location.country,
      temperature: payload.current.temp,
      feelsLike: payload.current.feelsLike,
      humidity: payload.current.humidity,
      pressure: payload.current.pressure,
      windSpeed: payload.current.windSpeed,
      windDirection: payload.current.windDeg,
      description: payload.current.description,
      weatherCode: payload.current.weatherCode,
      icon: payload.current.icon,
      forecast: payload.forecast,
      updatedAt: new Date().toISOString(),
    };

    const existingIndex = store.weatherCache.findIndex((item) => item.cityLower === cityLower);
    if (existingIndex >= 0) {
      store.weatherCache[existingIndex] = {
        ...store.weatherCache[existingIndex],
        ...cacheItem,
      };
    } else {
      store.weatherCache.push(cacheItem);
    }
    writeFallbackStore(store);
    return;
  }

  await WeatherCache.findOneAndUpdate(
    { cityLower: String(city).trim().toLowerCase() },
    {
      $set: {
        city: String(payload.location.name || city).trim(),
        cityLower: String(city).trim().toLowerCase(),
        latitude: payload.location.latitude,
        longitude: payload.location.longitude,
        country: payload.location.country,
        temperature: payload.current.temp,
        feelsLike: payload.current.feelsLike,
        humidity: payload.current.humidity,
        pressure: payload.current.pressure,
        windSpeed: payload.current.windSpeed,
        windDirection: payload.current.windDeg,
        description: payload.current.description,
        weatherCode: payload.current.weatherCode,
        icon: payload.current.icon,
        forecast: payload.forecast,
      },
    },
    { upsert: true, new: true }
  );
}

module.exports = {
  WeatherSearch,
  WeatherCache,
  logSearch,
  getSearchHistory,
  getWeatherCache,
  upsertWeatherCache,
};
