const crypto = require("crypto");
const { mongoose, isFallbackMode, readFallbackStore, writeFallbackStore } = require("../config/db");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true,
    },
  },
  { timestamps: true }
);

userSchema.set("toJSON", {
  virtuals: true,
  versionKey: false,
  transform: (_doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    return ret;
  },
});

const User = mongoose.models.User || mongoose.model("User", userSchema);

async function createUser(name, email) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    const normalizedEmail = String(email).trim().toLowerCase();
    const existingUser = store.users.find((user) => user.email === normalizedEmail);

    if (existingUser) {
      return existingUser;
    }

    const user = {
      id: crypto.randomUUID(),
      name: String(name).trim(),
      email: normalizedEmail,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    store.users.push(user);
    writeFallbackStore(store);
    return user;
  }

  const user = await User.create({
    name: String(name).trim(),
    email: String(email).trim().toLowerCase(),
  });
  return user.toJSON();
}

async function getUserById(userId) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    return store.users.find((user) => user.id === userId) || null;
  }

  if (!mongoose.Types.ObjectId.isValid(userId)) {
    return null;
  }

  const user = await User.findById(userId).lean();
  if (!user) return null;
  return {
    id: user._id.toString(),
    name: user.name,
    email: user.email,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };
}

async function getUserByEmail(email) {
  if (isFallbackMode()) {
    const store = readFallbackStore();
    return store.users.find((user) => user.email === String(email).trim().toLowerCase()) || null;
  }

  const user = await User.findOne({ email: String(email).trim().toLowerCase() }).lean();
  if (!user) return null;
  return {
    id: user._id.toString(),
    name: user.name,
    email: user.email,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };
}

module.exports = {
  User,
  createUser,
  getUserById,
  getUserByEmail,
};
