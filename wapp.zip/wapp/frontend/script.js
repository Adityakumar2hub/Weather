const API_BASE = window.location.protocol === "file:"
  ? "http://localhost:5000/api"
  : "/api";

const searchForm = document.getElementById("searchForm");
const authForm = document.getElementById("authForm");
const cityInput = document.getElementById("cityInput");
const nameInput = document.getElementById("nameInput");
const emailInput = document.getElementById("emailInput");
const errorMsg = document.getElementById("errorMsg");
const loading = document.getElementById("loading");
const currentWeather = document.getElementById("currentWeather");
const forecastSection = document.getElementById("forecastSection");
const emptyState = document.getElementById("emptyState");
const favoritesList = document.getElementById("favoritesList");
const historyList = document.getElementById("historyList");
const userStatus = document.getElementById("userStatus");
const dbStatus = document.getElementById("dbStatus");
const refreshFavorites = document.getElementById("refreshFavorites");
const refreshHistory = document.getElementById("refreshHistory");

let currentWeatherCity = "";

const emojiMap = {
  "01d": "☀️",
  "01n": "🌙",
  "02d": "⛅",
  "02n": "☁️",
  "03d": "☁️",
  "03n": "☁️",
  "04d": "☁️",
  "04n": "☁️",
  "09d": "🌧️",
  "09n": "🌧️",
  "10d": "🌦️",
  "10n": "🌧️",
  "11d": "⛈️",
  "11n": "⛈️",
  "13d": "❄️",
  "13n": "❄️",
  "50d": "🌫️",
  "50n": "🌫️",
};

function getEmoji(icon) {
  return emojiMap[icon] || "🌤️";
}

function getWindDirection(deg) {
  const dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  return dirs[Math.round(Number(deg || 0) / 45) % 8];
}

function getDayName(dateStr) {
  const date = new Date(`${dateStr}T00:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  if (date.getTime() === today.getTime()) return "Today";
  if (date.getTime() === tomorrow.getTime()) return "Tomorrow";
  return date.toLocaleDateString("en-US", { weekday: "short" });
}

function formatDate(dateStr) {
  return new Date(`${dateStr}T00:00:00`).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
}

function formatCityLabel(city) {
  return String(city || "")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function getStoredUser() {
  const raw = localStorage.getItem("weather_user");
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function setStoredUser(user) {
  localStorage.setItem("weather_user", JSON.stringify(user));
  updateUserStatus();
}

function getUserId() {
  const user = getStoredUser();
  return user?.id || null;
}

function showError(message) {
  errorMsg.textContent = message;
  errorMsg.style.display = "block";
}

function clearError() {
  errorMsg.textContent = "";
  errorMsg.style.display = "none";
}

function setDatabaseStatus(connected, state = "unknown") {
  if (!dbStatus) return;

  dbStatus.classList.remove("status-loading", "status-connected", "status-error");

  if (connected) {
    dbStatus.textContent = `Database connected (${state})`;
    dbStatus.classList.add("status-connected");
    return;
  }

  dbStatus.textContent = `Database not connected (${state})`;
  dbStatus.classList.add("status-error");
}

function detailItem(icon, label, value) {
  return `
    <div class="detail-item">
      <div class="icon">${icon}</div>
      <div class="label">${label}</div>
      <div class="value">${value}</div>
    </div>
  `;
}

function renderCurrentWeather(data, isFavorite = false) {
  currentWeatherCity = data.city;
  currentWeather.innerHTML = `
    <div class="current-top">
      <div class="current-info">
        <h2>${data.city}, ${data.country}</h2>
        <p class="desc">${data.description}</p>
      </div>
      <div class="current-temp">
        <span class="emoji">${getEmoji(data.icon)}</span>
        <span class="temp">${data.temp}°</span>
      </div>
    </div>
    <div class="weather-actions">
      <button type="button" class="primary-btn" id="favoriteBtn">${isFavorite ? "Saved to favorites" : "Save to favorites"}</button>
      <span class="source-tag">Live weather from backend</span>
    </div>
    <div class="details-grid">
      ${detailItem("🌡️", "Feels Like", `${data.feelsLike}°C`)}
      ${detailItem("💧", "Humidity", `${data.humidity}%`)}
      ${detailItem("💨", "Wind", `${data.windSpeed} m/s ${getWindDirection(data.windDeg)}`)}
      ${detailItem("📊", "Pressure", `${data.pressure} hPa`)}
      ${detailItem("👁️", "Visibility", `${(data.visibility / 1000).toFixed(1)} km`)}
      ${detailItem("☁️", "Clouds", `${data.clouds}%`)}
      ${detailItem("🔻", "Min Temp", `${data.tempMin}°C`)}
      ${detailItem("🔺", "Max Temp", `${data.tempMax}°C`)}
    </div>
  `;
  currentWeather.style.display = "block";
  emptyState.style.display = "none";

  const favoriteBtn = document.getElementById("favoriteBtn");
  favoriteBtn.disabled = Boolean(isFavorite);
  favoriteBtn.addEventListener("click", saveFavoriteForCurrentCity);
}

function renderForecast(forecast) {
  if (!forecast || forecast.length === 0) {
    forecastSection.style.display = "none";
    return;
  }

  forecastSection.innerHTML = `
    <h3>5-Day Forecast</h3>
    <div class="forecast-grid">
      ${forecast
        .map(
          (day) => `
            <div class="forecast-card">
              <div class="day">${getDayName(day.date)}</div>
              <div class="date">${formatDate(day.date)}</div>
              <span class="emoji">${getEmoji(day.icon)}</span>
              <div class="temp">${day.temp}°</div>
              <div class="condition">${day.description}</div>
              <div class="range">🔻${day.tempMin}° 🔺${day.tempMax}°</div>
            </div>
          `
        )
        .join("")}
    </div>
  `;
  forecastSection.style.display = "block";
}

function renderFavorites(favorites) {
  if (!favorites || favorites.length === 0) {
    favoritesList.innerHTML = `<div class="empty-list">No favorites yet. Save a city after searching.</div>`;
    return;
  }

  favoritesList.innerHTML = favorites
    .map(
      (favorite) => `
        <div class="list-item">
          <button type="button" class="link-btn favorite-city" data-city="${favorite.city}">${formatCityLabel(favorite.city)}</button>
          <button type="button" class="ghost-btn danger-btn remove-favorite" data-city="${favorite.city}">Remove</button>
        </div>
      `
    )
    .join("");

  document.querySelectorAll(".favorite-city").forEach((button) => {
    button.addEventListener("click", () => searchCity(button.dataset.city));
  });

  document.querySelectorAll(".remove-favorite").forEach((button) => {
    button.addEventListener("click", async () => {
      const userId = getUserId();
      if (!userId) return;
      await fetch(`${API_BASE}/users/${userId}/favorites/${encodeURIComponent(button.dataset.city)}`, {
        method: "DELETE",
      });
      await loadFavorites();
    });
  });
}

function renderHistory(history) {
  if (!history || history.length === 0) {
    historyList.innerHTML = `<div class="empty-list">Your searches will appear here.</div>`;
    return;
  }

  historyList.innerHTML = history
    .map(
      (item) => `
        <div class="list-item history-item">
          <button type="button" class="link-btn history-city" data-city="${item.city}">${item.city}</button>
          <span class="meta">${new Date(item.searched_at).toLocaleString()}</span>
        </div>
      `
    )
    .join("");

  document.querySelectorAll(".history-city").forEach((button) => {
    button.addEventListener("click", () => searchCity(button.dataset.city));
  });
}

function updateUserStatus() {
  const user = getStoredUser();
  if (!user) {
    userStatus.textContent = "No user selected";
    return;
  }

  userStatus.textContent = `Signed in as ${user.name} (${user.email})`;
  nameInput.value = user.name || "";
  emailInput.value = user.email || "";
}

async function loadFavorites() {
  const userId = getUserId();
  if (!userId) {
    favoritesList.innerHTML = `<div class="empty-list">Register to save favorites.</div>`;
    return;
  }

  const response = await fetch(`${API_BASE}/users/${userId}/favorites`);
  const data = await response.json();
  renderFavorites(data.favorites || []);
}

async function loadHistory() {
  const userId = getUserId();
  const response = await fetch(
    `${API_BASE}/searches${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`
  );
  const data = await response.json();
  renderHistory(data.searches || []);
}

async function loadHealth() {
  try {
    const response = await fetch(`${API_BASE}/health`);
    const data = await response.json();
    setDatabaseStatus(Boolean(data.database?.connected), data.database?.state || "unknown");
  } catch (error) {
    setDatabaseStatus(false, "unreachable");
  }
}

async function saveFavoriteForCurrentCity() {
  const userId = getUserId();
  if (!userId) {
    showError("Please save your profile first, then add favorites.");
    return;
  }

  if (!currentWeatherCity) return;

  const response = await fetch(`${API_BASE}/users/${userId}/favorites`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ city: currentWeatherCity }),
  });

  if (!response.ok) {
    showError("Could not save favorite city.");
    return;
  }

  const favoriteBtn = document.getElementById("favoriteBtn");
  if (favoriteBtn) {
    favoriteBtn.textContent = "Saved to favorites";
    favoriteBtn.disabled = true;
  }

  await loadFavorites();
}

async function fetchWeather(city) {
  const userId = getUserId();
  const response = await fetch(
    `${API_BASE}/weather/${encodeURIComponent(city)}${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`
  );
  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || "Failed to fetch weather data");
  }

  return data;
}

async function searchCity(city, fromClick = false) {
  const cleanCity = String(city || "").trim();
  if (!cleanCity) return;

  if (!fromClick) {
    cityInput.value = cleanCity;
  }

  clearError();
  loading.style.display = "flex";
  currentWeather.style.display = "none";
  forecastSection.style.display = "none";
  emptyState.style.display = "none";

  try {
    const result = await fetchWeather(cleanCity);
    renderCurrentWeather(result.data.current, result.isFavorite);
    renderForecast(result.data.forecast);
    await loadHistory();
    if (getUserId()) {
      await loadFavorites();
    }
  } catch (error) {
    showError(error.message);
    emptyState.style.display = "block";
  } finally {
    loading.style.display = "none";
  }
}

searchForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  await searchCity(cityInput.value);
});

authForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearError();

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  if (!name || !email) {
    showError("Please enter your name and email.");
    return;
  }

  try {
    const response = await fetch(`${API_BASE}/users/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email }),
    });
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.message || "Could not save profile");
    }

    setStoredUser(data.user);
    await loadFavorites();
    await loadHistory();
  } catch (error) {
    showError(error.message);
  }
});

refreshFavorites.addEventListener("click", loadFavorites);
refreshHistory.addEventListener("click", loadHistory);

document.querySelectorAll("[data-city]").forEach((button) => {
  button.addEventListener("click", () => searchCity(button.dataset.city));
});

window.searchCity = searchCity;

async function bootstrap() {
  updateUserStatus();
  await loadHealth();
  await loadFavorites();
  await loadHistory();
}

bootstrap();
